SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=false
REPLACE="
"
rm -rf /storage/emulated/0/MIUI_odex/odex.sh
mv $TMPDIR/common/odex.sh /storage/emulated/0/MIUI_odex/odex.sh
rm -rf /data/adb/modules/test
rm -rf /data/adb/modules_update/test